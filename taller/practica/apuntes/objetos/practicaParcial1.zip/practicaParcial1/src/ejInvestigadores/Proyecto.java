/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejInvestigadores;

/**
 *
 * @author pame
 */
public class Proyecto {
    private String nombre ; 
    private int codigo; 
    private String director; 
    private Investigador [] investigadores = new Investigador[50];
    private int totalInvestigadores= 0; 

    public Proyecto(String nombre, int codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
    }
    
    public void agregarInvestigador(Investigador unInvestigador) {
        if (totalInvestigadores  < 50) {
            investigadores[totalInvestigadores] = unInvestigador;
            totalInvestigadores++; 
            System.out.println("Se ha agreado un investigador al proyecto"); //debugging
        } 
        else
            System.out.println("proyecto completo. No se aceptan más investigadores.");
    }
    
    public double dineroTotalOtorgado(){
     double total = 0;    
     for (int i=0; i<totalInvestigadores; i++){
         total = total + investigadores[i].montoTotalSubsidiosOtorgados();
     }
     return total; 
    }
    
    public int cantidadDeSubsidios(String nombre_Y_apellido){
        boolean ok = false; int pos = 0; int aux = 0; 
        while ((!ok) && (pos < totalInvestigadores)){
           if (investigadores[pos].getNombreYapellido().equals(nombre_Y_apellido)){
               ok = true;
               aux = investigadores[pos].getTotalSubsidios(); 
           }
           else 
               pos ++;
        }
        return aux; 
    }

    public void otorgarTodos(String nombre_y_apellido){
        boolean ok = false; int pos = 0; 
        while ((!ok) && (pos < totalInvestigadores)){
            if (investigadores[pos].getNombreYapellido().equals(nombre_y_apellido)){
                ok=true; 
                investigadores[pos].otorgarSubsidios();
            }
        } 
    }
    
    public void otorgarTodos2(String nombre_y_apellido){
        int pos = 0; 
        while (!(investigadores[pos].getNombreYapellido().equals(nombre_y_apellido)) && (pos < totalInvestigadores)){
            pos++; 
        } 
        if (investigadores[pos].getNombreYapellido().equals(nombre_y_apellido)){
            investigadores[pos].otorgarSubsidios();
        }
    }    

    public void setDirector(String director) {
        this.director = director;
    }

    public int getTotalInvestigadores() {
        return totalInvestigadores;
    }
    
    @Override
    public String toString() {
        String aux = "Proyecto " + nombre +"\n"+ "codigo:" + codigo +"\n" +"director:" + director + "\n"+ "dinero otorgado en subsidios: "+dineroTotalOtorgado()+"\n" ;
        for (int i=0; i< totalInvestigadores; i++ ){
            aux = aux+ "investigadores: " +"\n"+ investigadores[i].getNombreYapellido()+ "\n"+ "especialidad: " 
                    + investigadores[i].getEspecialidad()+ "\n"+ "monto total otorgado: "
                    + investigadores[i].montoTotalSubsidiosOtorgados();
        }
        return aux; 
    }
        
    
}
