/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejInvestigadores;

/**
 *
 * @author pame
 */
public class Investigador {

    private String nombreYapellido;
    private int categoria;
    private String especialidad;
    private Subsidio[] subsidios = new Subsidio[5];
    private int totalSubsidios = 0;

    public Investigador(String nombreYapellido, int categoria, String especialidad) {
        this.nombreYapellido = nombreYapellido;
        this.categoria = categoria;
        this.especialidad = especialidad;
    }

    public void agregarSubsidio(Subsidio unSubsidio) {
        if (totalSubsidios < 5) { 
            subsidios[totalSubsidios] = unSubsidio;
            totalSubsidios++; 
            System.out.println("Se ha agregado un nuevo subsidio");
        } else {
            System.out.println("Se ha alcanzado el máximo de subsidios permitidos");
        }
    }

    public double montoTotalSubsidiosOtorgados() {
        double total = 0;
        for (int i = 0; i < totalSubsidios; i++) {
            if (subsidios[i].isOtorgado() == true)
                total = total + subsidios[i].getMonto();
        }
        return total;
    }

    public void otorgarSubsidios() {
        for (int i = 0; i < totalSubsidios; i++) {
            subsidios[i].setOtorgado(true);
        }
    }

    public int getCategoria() {
        return categoria;
    }

    public Subsidio[] getSubsidios() {
        return subsidios;
    }

    public int getTotalSubsidios() {
        return totalSubsidios;
    }

    public String getNombreYapellido() {
        return nombreYapellido;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    
    
}

