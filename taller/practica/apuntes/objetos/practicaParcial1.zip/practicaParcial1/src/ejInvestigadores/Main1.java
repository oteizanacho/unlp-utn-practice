/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejInvestigadores;

//import PaqueteLectura.Lector;

/**
 *
 * @author pame
 */
public class Main1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Proyecto p1 = new Proyecto("proyecto1", 100);    
        
        p1.setDirector("Prof Splinter");   
        
        Investigador i1= new Investigador("Michelangelo", 5, "tortuga"); 
        Investigador i2= new Investigador("Donatello", 3, "tortuga");  
        
        p1.agregarInvestigador(i1);
        p1.agregarInvestigador(i2);

        Subsidio s1 = new Subsidio(12.00,"lechuga");
        Subsidio s2 = new Subsidio(50.00, "pepino"); 
        
        i1.agregarSubsidio(s1);
        i1.agregarSubsidio(s2);
        
        Subsidio s3 = new Subsidio(100, "pizza");        
        Subsidio s4 = new Subsidio(200, "pizza con pepperoni");   
        
        i2.agregarSubsidio(s3);
        i2.agregarSubsidio(s4);

        p1.otorgarTodos2("Donatello"); 
        
        System.out.println(p1.toString());  
    }
    
}
