/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2;

import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

public class PruebaEstacionamiento {

    
    public static void main(String[] args) {
        
        Estacionamiento e = new Estacionamiento("LP parking", "12 e 51 y 53");//, "7:30", "22:00",3,3);
  
        //GeneradorAleatorio.iniciar();
        //patente = GeneradorAleatorio.generarInt(11); 
        System.out.println("Ingresa patente ");
        int patente = Lector.leerInt();

        while (patente != 0){
            if(patente % 2 == 0){
                System.out.println("+ Podes pasar " + patente);
                
                System.out.println("Ingrese piso - 0-4");
                int piso = Lector.leerInt();
                System.out.println("Ingrese plaza - 0-9");
                int plaza = Lector.leerInt();
                
                String dueño= GeneradorAleatorio.generarString(6);
                
                //CREAR EL OBJETO AUTO
                Auto a = new Auto();
                a.setPatente(patente);
                a.setDueño(dueño);
                
                e.estacionar(a, piso, plaza);
                
            }
            else
                System.out.println("- No podes pasar " + patente);
            
          //  patente = GeneradorAleatorio.generarInt(11); 
            System.out.println("Ingresa patente ");
            patente = Lector.leerInt();
        }
        
        System.out.println(e.toString());
        
        System.out.println("Ingresa patente a buscar ");
        int buscado = Lector.leerInt();
        System.out.println(e.buscarPorPatente(buscado));
        
    }
   
    
}
