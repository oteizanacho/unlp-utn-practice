/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2;

public class Estacionamiento {
    

    //ESTADO 
    private String nombre;
    private String direccion;
    private String horaApertura;
    private String horaCierre;
    private int DIMF;
    private int DIMC;
    private Auto[][] ubicaciones;
    
    
    
    
    //CONSTRUCTORES
    
    /*Implemente un constructor que reciba nombre y dirección, e inicie el
    estacionamiento con hora de apertura “8:00”, hora de cierre “21:00”, y para 5 pisos y
    10 plazas por piso. El estacionamiento inicialmente no tiene autos     
    */
    public Estacionamiento(String nombre, String direccion){
        this.nombre = nombre;
        this.direccion = direccion; 
        this.horaApertura = "8:00";
        this.horaCierre= "21:00";
        this.DIMF= 5;
        this.DIMC= 10;
        ubicaciones = new Auto[DIMF][DIMC];
        this.inicializarUbicaciones();
    }
    
     /*
    Implemente un segundo constructor que reciba nombre, dirección, hora de
    apertura, hora de cierre, el número de pisos (N) y el número de plazas por piso (M)
    e inicie el estacionamiento con los datos recibidos, y sin autos.
    */
    public Estacionamiento(String nombre, String direccion, String horaApertura, String horaCierre, int piso, int plaza){
        this.nombre = nombre;
        this.direccion = direccion; 
        this.horaApertura = horaApertura;
        this.horaCierre= horaCierre;
        this.DIMF= piso;
        this.DIMC= plaza;
        ubicaciones = new Auto[DIMF][DIMC];
        this.inicializarUbicaciones();
    }
    
    
    
    
    //METODOS
    
    private void inicializarUbicaciones(){
        int i,j;
        for(i=0; i< DIMF;i++){
            for (j=0; j< DIMC;j++){
                ubicaciones[i][j] = null;
            }
        }       
        
    }
    
    
    
    /*Dado un auto A, un número de piso X y un número de plaza Y, registrar al auto en
      el estacionamiento en el lugar X,Y. Suponga que X, Y son válidos y que el lugar
      está desocupado*/
    public void estacionar(Auto a, int piso, int plaza){
        ubicaciones[piso][plaza] = a;
        
    }
    
    
    
     /*
    Dada una patente, obtener un string que contenga el número de piso y plaza
    donde está dicho auto. En caso de no encontrarse, retornar el mensaje “Auto 
    Inexistente”.
    */
    public String buscarPorPatente(int p){
        
        int i=0,j=0; // variables para recorrer la matriz
        
        boolean encontre=false; 
        
        while((i<DIMF)&&(!encontre)){
            
            j=0;
            while((j<DIMC)&&(!encontre)){
                
                if((ubicaciones[i][j]!= null)&&(ubicaciones[i][j].getPatente() == p))
                    encontre=true;
                else
                    j++;
                
            }
            if (!encontre) i++;
        }
        
        String aux;
        if (encontre){
            aux= "El auto con patente "+ p + " se encuentra en el Piso " + i+" en la plaza "+j;
        }
        else 
            aux="Auto inexistente";
        return aux;   
    }
    
    
    
    
    
    @Override
    public String toString(){
        
        int i,j; // variables para recorrer la matriz
        String aux = ""; // string a retornar
        
        for(i=0;i<DIMF;i++){
            
            for (j=0;j<DIMC;j++){
                
                aux = aux + "Piso " + i + " Plaza " + j;
                
                if (ubicaciones[i][j] != null)
                   aux = aux + " --> "+ ubicaciones[i][j].toString() + "\n";
                else
                    aux = aux + " --> libre \n";
                   
            }
        }
        return aux;
    }

    
    
    
    
    //GETTERS y SETTERS

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getHoraApertura() {
        return horaApertura;
    }

    public String getHoraCierre() {
        return horaCierre;
    }

    public int getDIMF() {
        return DIMF;
    }

    public int getDIMC() {
        return DIMC;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setHoraApertura(String horaApertura) {
        this.horaApertura = horaApertura;
    }

    public void setHoraCierre(String horaCierre) {
        this.horaCierre = horaCierre;
    }
    
    
    
}
