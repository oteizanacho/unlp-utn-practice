package clase3;

public class UrnaElectoral extends Urna{
    
    private int cantListas;       //Cantidad de lista que se presentan (Dim Fis del vector)
    private int [] votosPorLista; //Vector de contadores de votos 

    public UrnaElectoral(int nro, int cantL){
        
        super(nro); 
        
        cantListas = cantL; 
        votosPorLista = new int[cantListas];
                
        //inicializa contadores
        for (int i=0; i < cantListas; i++){
            votosPorLista[i] = 0;
        }
    }
    
    
    public final int getCantListas() {
        return cantListas;
    }
    
    public boolean validarNumeroDeLista(int N){
        return ( (N >= 0) && (N < getCantListas()) );
    }
    
    public void votarPorLista(int nroL){
       votosPorLista[nroL]++;
    }
    
    public int devolverVotosPorLista(int nroL){
        return votosPorLista[nroL];
    }
    
    @Override
    public int calcularGanador(){
        int max = -1, imax = -1;
        for(int i=0; i < cantListas; i++){
            if (votosPorLista[i] > max){
                max=votosPorLista[i];
                imax=i;
            }
        }
        return imax;    
    }
    
    
    @Override
     public  int calcularTotalVotos(){
        
        int suma = this.getVotosBlanco();
        
        for(int i=0; i<cantListas; i++){
            suma = suma + votosPorLista[i];
        }
        return suma;       
     }
    
    
    
}
