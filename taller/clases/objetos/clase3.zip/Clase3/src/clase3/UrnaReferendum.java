package clase3;

public class UrnaReferendum extends Urna{
    
   private int votosFavor;
   private int votosContra;
   
   public UrnaReferendum(int nro){
       super(nro);
       
       votosFavor = 0;  //contador de votos a favor
       votosContra = 0; //contador de votos en contra
   }

    public int getVotosFavor() {
        return votosFavor;
    }

    public int getVotosContra() {
        return votosContra;
    }

    public void votarAFavor(){
        votosFavor++;
    }
   
    public void votarEnContra(){
        votosContra++;
    }
 
    
   @Override
    public int calcularGanador(){
        int aux = -1;
        
        if (getVotosContra() > getVotosFavor())
                aux=0;
        else 
            if (getVotosContra() < getVotosFavor())
                aux=1;
        
        return aux;
    }
    
    
   
    
   @Override
    public  int calcularTotalVotos(){
        return (getVotosBlanco() + getVotosFavor() + getVotosContra() );
    }
    
}
