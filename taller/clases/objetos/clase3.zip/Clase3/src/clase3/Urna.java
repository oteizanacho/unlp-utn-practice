package clase3;

public abstract class Urna {
    
    private int numero;
    private int votosBlanco;
    
    public Urna(int numero){
        this.numero = numero;
        this.votosBlanco = 0;
    }

    public int getNumero() {
        return numero;
    }

    public int getVotosBlanco() {
        return votosBlanco;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    public void votarEnBlanco (){
        votosBlanco++;
    }
    
    public abstract int calcularGanador();
    public abstract int calcularTotalVotos();
    
}
