package clase3;

import PaqueteLectura.Lector;

public class Clase3 {

    
    public static void main(String[] args) {
        
        UrnaElectoral urnaE = new UrnaElectoral(203, 5);
        UrnaReferendum urnaR = new UrnaReferendum(203);
        
        System.out.println("Ingrese DNI");
        int DNI = Lector.leerInt();
        
        while (DNI != 0){
            
            //Voto electoral
            System.out.println("Voto Electoral -> Ingrese nro. lista");
            int N = Lector.leerInt();
            if (urnaE.validarNumeroDeLista(N))
                urnaE.votarPorLista(N); 
            else
                urnaE.votarEnBlanco();
                
            //Voto Referendum
            System.out.println("Voto Referendum -> Ingrese nro: +/-/0");
            int M = Lector.leerInt();
            if (M > 0) 
                urnaR.votarAFavor();
            else 
                if (M < 0)
                    urnaR.votarEnContra();
                else 
                    urnaR.votarEnBlanco();
            
            System.out.println("Ingrese DNI");
            DNI= Lector.leerInt();
        }
        
        //Informar resultados
        System.out.println("\n ------------------------------------- \n Urna Electoral \n ");
        int ganador = urnaE.calcularGanador();
        int totalVotos = urnaE.calcularTotalVotos();
        int votosGanador = urnaE.devolverVotosPorLista(ganador);
        
        double porcentaje = 0 ;
        if(totalVotos > 0)
            porcentaje = ((double) votosGanador*100)/ totalVotos;
        
        System.out.println(" Ganador: "+ ganador);    
        System.out.println(" Porcentaje: "+ porcentaje);   
        
        //referendum
        System.out.println("\n ------------------------------------- \n Urna Referendum \n ");
        
        ganador = urnaR.calcularGanador(); //-1: empate; 0: En Contra; 1:A Favor. 
        totalVotos = urnaR.calcularTotalVotos();
        
        switch(ganador){ 
            case 1: //Gano A Favor
                votosGanador = urnaR.getVotosFavor();
                System.out.println(" Ganador: A favor");    
                break;
            case 0: //Gano En conra
                votosGanador = urnaR.getVotosContra();
                System.out.println(" Ganador: En contra");
                break;
            default: //empate. No calculamos el porcentaje
                System.out.println(" Ganador: Empate");
        }
        
        if(ganador >= 0){ // solo mostramos porcenaje si hubo ganador
            porcentaje = ((double) votosGanador*100)/ totalVotos;
            System.out.println(" Porcentaje: "+ porcentaje);   
        }        
    }
    
}
